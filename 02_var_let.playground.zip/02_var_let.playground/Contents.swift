import UIKit

// Constant/static value => let
let maximunNumberOfLoginAttempts = 3

// Variable/dinamic value => var
var currentLoginAttempt = 0

// Option of declarate many variables
var x = 0.0,
    y = 0.0,
    z = 0.0

// No initial value => Type that
var welcomeMessage :String // This vaiable has be a string value in a future

welcomeMessage = "Hello, What's up?" // Set value of variable welcomeMessage

var red,
    green,
    blue :Double // red, green and blue are a double variables

// Interpolation
print("The number of actual login is: \(currentLoginAttempt) of \(maximunNumberOfLoginAttempts)")

/*
 
 */
