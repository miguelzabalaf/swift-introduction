import UIKit

typealias AudioSample = UInt16

var maxAplitude = AudioSample.max // UInt16.max
