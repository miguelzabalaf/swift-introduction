import UIKit

let orangersAreOrange = true

let foodIsDelicious = false

var isAged : Bool

isAged = false

if isAged {
    print("You can entry to a party")
} else {
    print("You can't entry to a party :(")
}
